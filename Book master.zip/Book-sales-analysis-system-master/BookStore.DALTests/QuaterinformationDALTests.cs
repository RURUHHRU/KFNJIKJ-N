﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BookStore.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore.DAL.Tests
{
    [TestClass()]
    public class QuaterinformationDALTests
    {
        [TestMethod()]
        public void GetQuaterinformByQuaterAndusernameTest()
        {
            Assert.Fail();
        }
    }
}