﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BookStore.DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore.DAL.Tests
{
    [TestClass()]
    public class UserDALTests
    {
        [TestMethod()]
        public void AddUserTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void UpdateUserTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void SoftDeleteTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void RealDeleteTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void DeletesTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void GetAllUsersTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void UpdatePwdTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void GetUserByLoginNameAndPasswordTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void GetUserByLoginNameTest()
        {
            Assert.Fail();
        }
    }
}