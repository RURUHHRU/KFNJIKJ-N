﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore.Model
{
    public class Quaterinformation
    {
        public int Quater { get; set; }
        public string Bookname { get; set; }
        public int Sellcount { get; set; }
        public int Ordercount { get; set; }
        public string username { get; set; }
    }
}
